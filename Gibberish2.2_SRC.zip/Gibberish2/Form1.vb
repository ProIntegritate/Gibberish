﻿Public Class Form1

    ' Written as a proof of concent by Glenn Larsson, 2015 (1973gl@gmail.com).
    ' Please refrain from using it IRL, unless you can take the consequences of using concept code.

    ' Capture keydown events (for hotkey)
    Public Declare Function GetAsyncKeyState Lib "user32" (ByVal vKey As Long) As Integer
    Private Declare Sub keybd_event Lib "user32" (ByVal bVk As Byte, ByVal bScan As Byte, ByVal dwflags As Long, ByVal dwExtraInfo As Long)

    Public bSetting As Boolean = False
    Public sFilename As String = ""
    Public sLocalSeed As String = ""

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Dim hSHA As New System.Security.Cryptography.SHA256Cng

        ' Populate sLocalseed with defaultvalue for unique subset.
        sLocalSeed = Environ("computername") & Environ("userprofile") & Environ("PROCESSOR_IDENTIFIER") & Now ' Now = Datestring
        Dim bLocalseed() As Byte = {0, 0}
        bLocalseed = System.Text.Encoding.UTF8.GetBytes(sLocalSeed)
        bLocalseed = hSHA.ComputeHash(bLocalseed)
        sLocalSeed = Convert.ToBase64String(bLocalseed) ' b64 representation of localseed

        Dim sPath As String = Application.StartupPath & "\entropy.txt"
        If InStr(1, sPath, "Debug") > 0 Then sPath = "S:\test\entropy.txt"

        sFilename = sPath ' set global

        Me.cbItemList.Items.Clear()

        ' Start parsing entropyfile
        If Dir(sPath) <> "" Then
            Dim i As Integer = FreeFile()
            Dim sReadLine As String = ""
            FileOpen(i, sPath, OpenMode.Input)
            While Not EOF(i)
                sReadLine = LineInput(i)
                If Microsoft.VisualBasic.Left(sReadLine, 3) = "LS=" Then ' Localseed param
                    sLocalSeed = sReadLine.Replace("LS=", "")
                    sReadLine = ""
                End If
                sReadLine = sReadLine.Replace(vbCr, "")
                sReadLine = sReadLine.Replace(vbLf, "")
                If sReadLine.Trim <> "" Then Me.cbItemList.Items.Add(sReadLine)
            End While
            FileClose(i)

        End If

    End Sub

    ' STATUS: DONE
    Private Sub GenPWD()

        Dim bEntropyHash() As Byte = {0, 0} ' dummyarray 
        Dim sEntropyString As String = ""
        Dim bPwdHash() As Byte = {0, 0} ' dummyarray 

        Dim iVariant As Integer = 0
        Dim sResult As String = ""

        Dim hSHA As New System.Security.Cryptography.SHA256Cng

        ' Get entropy
        If cbItemList.SelectedIndex = -1 Then Exit Sub
        sEntropyString = cbItemList.Items.Item(cbItemList.SelectedIndex).ToString
        If sEntropyString.Trim = "" Then Exit Sub ' v2.1
        bEntropyHash = System.Text.Encoding.UTF8.GetBytes(sEntropyString & sLocalSeed) ' Localseed injected and ready.
        bEntropyHash = hSHA.ComputeHash(bEntropyHash) ' reduce once to 31 bytes

        If txtPasswordPassphrase.Text.ToString.Trim = "" Then Exit Sub ' v2.1
        bPwdHash = System.Text.Encoding.UTF8.GetBytes(txtPasswordPassphrase.Text.ToString)
        bPwdHash = hSHA.ComputeHash(bPwdHash) ' reduce once to 31 bytes

        ' iVariant represents the number of extra rounds we should add to PKCS #7. This makes the hashing password dependent, stronger and voids dictionary attacks.
        For n = 0 To 31
            iVariant = iVariant Xor bPwdHash(n)
        Next n

        For n = 0 To (999 + iVariant)
            ' Inject entropyhash roughly in the middle of the hashing process, also iVariant dependent.
            If n = (500 + iVariant) Then
                For X = 0 To 31
                    bPwdHash(X) = bPwdHash(X) Xor bEntropyHash(X)
                Next X
            End If
            bPwdHash = hSHA.ComputeHash(bPwdHash) ' PKCS #7, specifying 1000 rounds.
        Next n

        sResult = Convert.ToBase64String(bPwdHash)

        sResult = sResult & sResult & sResult & sResult ' Concatenate in case shit happens

        Dim iMaxLen As Integer = 32 ' default to 32 chars (160 bits)

        If rb40bits.Checked = True Then iMaxLen = 8
        If rb60bits.Checked = True Then iMaxLen = 12
        If rb80bits.Checked = True Then iMaxLen = 16
        If rb120bits.Checked = True Then iMaxLen = 24
        If rb160bits.Checked = True Then iMaxLen = 32

        If cbSpecialChar.Checked = False Then
            sResult = sResult.Replace("+", "") ' Standard Base64
            sResult = sResult.Replace("=", "")
            sResult = sResult.Replace("/", "")
            sResult = sResult.Replace("-", "") ' FS compliant Base64
            sResult = sResult.Replace("_", "")
        End If

        If cbSpecialChar.Checked = True Then

            Dim iPosA As Integer = 0
            Dim iPosB As Integer = 0
            Dim iPosC As Integer = 0
            Dim iPosD As Integer = 0
            Dim iCharA As Integer = 0
            Dim iCharB As Integer = 0
            Dim iCharC As Integer = 0
            Dim iCharD As Integer = 0

            iPosA = ((bPwdHash(0) Xor bPwdHash(1) Xor bPwdHash(2) Xor bPwdHash(3) Xor bPwdHash(4) Xor bPwdHash(5) Xor bPwdHash(6) Xor bPwdHash(7)) Mod (iMaxLen - 1)) : iPosA = iPosA + 1
            iPosB = ((bPwdHash(8) Xor bPwdHash(9) Xor bPwdHash(10) Xor bPwdHash(11) Xor bPwdHash(12) Xor bPwdHash(13) Xor bPwdHash(14) Xor bPwdHash(15)) Mod (iMaxLen - 1)) : iPosB = iPosB + 1
            iPosC = ((bPwdHash(0) Xor bPwdHash(1) Xor bPwdHash(2) Xor bPwdHash(3) Xor bPwdHash(4) Xor bPwdHash(5) Xor bPwdHash(6) Xor bPwdHash(7)) Mod (iMaxLen - 1)) : iPosC = iPosC + 1
            iPosD = ((bPwdHash(8) Xor bPwdHash(9) Xor bPwdHash(10) Xor bPwdHash(11) Xor bPwdHash(12) Xor bPwdHash(13) Xor bPwdHash(14) Xor bPwdHash(15)) Mod (iMaxLen - 1)) : iPosD = iPosD + 1

            ' TODO - BUGG: Overflow om Xor blir 0xff, sätt "= 0 + ((" ? Fixed???
            iCharA = 1 + ((bPwdHash(16) Xor bPwdHash(17) Xor bPwdHash(18) Xor bPwdHash(19) Xor bPwdHash(20) Xor bPwdHash(21) Xor bPwdHash(22) Xor bPwdHash(23)) Mod 7)
            iCharB = 1 + ((bPwdHash(24) Xor bPwdHash(25) Xor bPwdHash(26) Xor bPwdHash(27) Xor bPwdHash(28) Xor bPwdHash(29) Xor bPwdHash(30) Xor bPwdHash(31)) Mod 7)
            iCharC = 1 + ((bPwdHash(16) Xor bPwdHash(17) Xor bPwdHash(18) Xor bPwdHash(19) Xor bPwdHash(20) Xor bPwdHash(21) Xor bPwdHash(22) Xor bPwdHash(23)) Mod 7)
            iCharD = 1 + ((bPwdHash(24) Xor bPwdHash(25) Xor bPwdHash(26) Xor bPwdHash(27) Xor bPwdHash(28) Xor bPwdHash(29) Xor bPwdHash(30) Xor bPwdHash(31)) Mod 7)

            Dim sSPECIALCHARS As String = ""
            sSPECIALCHARS = "!#${}()@"

            Mid(sResult, iPosA, 1) = Mid(sSPECIALCHARS, iCharA, 1)
            Mid(sResult, iPosB, 1) = Mid(sSPECIALCHARS, iCharB, 1)
            Mid(sResult, iPosC, 1) = Mid(sSPECIALCHARS, iCharC, 1)
            Mid(sResult, iPosD, 1) = Mid(sSPECIALCHARS, iCharD, 1)

        End If

        sResult = sResult.Replace("/", "%") ' TODO: Fundera på att byta ut. Inkompatibilitet med nuvarande lösenordsuppsättningar

        txtGeneratedPasword.Text = Microsoft.VisualBasic.Left(sResult, iMaxLen)

    End Sub

    ' STATUS: DONE
    Private Sub cmdHelpPwdStrenght_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdHelpPwdStrenght.Click
        MsgBox("While some sites and systems allows unlimited size passwords, some sites are coded only to accept 8 characters, or only between 8 to 16 characters." & vbCrLf & vbCrLf & "This is idiotic, but some ''developers'' actually do this. This box allows you to downgrade strenght so you will get a shorter password that works with the specific site." & vbCrLf & vbCrLf & "You can also turn off generation of special characters if the site wont accept those.", MsgBoxStyle.Information, "A note on password strength:")
    End Sub

    ' STATUS: DONE
    Private Sub txtPasswordPassphrase_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtPasswordPassphrase.TextChanged

        Dim sResult As String = ""
        Dim bHash() As Byte = {0, 0}

        Dim hSHA As New System.Security.Cryptography.SHA256Cng


        bHash = System.Text.Encoding.UTF8.GetBytes(txtPasswordPassphrase.Text.ToString)
        bHash = hSHA.ComputeHash(bHash)

        sResult = ""
        sResult = sResult & Microsoft.VisualBasic.Right("0" & Hex(bHash(0)), 2)
        sResult = sResult & Microsoft.VisualBasic.Right("0" & Hex(bHash(31)), 2)

        txtPwHint.Text = sResult ' This isnt anything cept a "minihash" to allow the user to know what he/she wrote, without revealing the password to anyone looking at the screen.

        Call GenPWD()

    End Sub

    ' STATUS: DONE
    Private Sub rb40bits_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rb40bits.CheckedChanged
        If bSetting = True Then Exit Sub
        bSetting = True
        rb40bits.Checked = True
        rb60bits.Checked = False
        rb80bits.Checked = False
        rb120bits.Checked = False
        rb160bits.Checked = False
        bSetting = False

        If cbItemList.SelectedIndex = -1 Then Exit Sub
        Dim sResult As String = cbItemList.Items.Item(cbItemList.SelectedIndex).ToString
        sResult = sResult.Replace("|60|", "|40|")
        sResult = sResult.Replace("|80|", "|40|")
        sResult = sResult.Replace("|120|", "|40|")
        sResult = sResult.Replace("|160|", "|40|")
        cbItemList.Items.Item(cbItemList.SelectedIndex) = sResult

        Call GenPWD()
    End Sub
    ' STATUS: DONE
    Private Sub rb60bits_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rb60bits.CheckedChanged
        If bSetting = True Then Exit Sub
        bSetting = True
        rb40bits.Checked = False
        rb60bits.Checked = True
        rb80bits.Checked = False
        rb120bits.Checked = False
        rb160bits.Checked = False
        bSetting = False

        If cbItemList.SelectedIndex = -1 Then Exit Sub
        Dim sResult As String = cbItemList.Items.Item(cbItemList.SelectedIndex).ToString
        sResult = sResult.Replace("|40|", "|60|")
        sResult = sResult.Replace("|80|", "|60|")
        sResult = sResult.Replace("|120|", "|60|")
        sResult = sResult.Replace("|160|", "|60|")
        cbItemList.Items.Item(cbItemList.SelectedIndex) = sResult

        Call GenPWD()
    End Sub
    ' STATUS: DONE
    Private Sub rb80bits_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rb80bits.CheckedChanged
        If bSetting = True Then Exit Sub
        bSetting = True
        rb40bits.Checked = False
        rb60bits.Checked = False
        rb80bits.Checked = True
        rb120bits.Checked = False
        rb160bits.Checked = False
        bSetting = False

        If cbItemList.SelectedIndex = -1 Then Exit Sub
        Dim sResult As String = cbItemList.Items.Item(cbItemList.SelectedIndex).ToString
        sResult = sResult.Replace("|40|", "|80|")
        sResult = sResult.Replace("|60|", "|80|")
        sResult = sResult.Replace("|120|", "|80|")
        sResult = sResult.Replace("|160|", "|80|")
        cbItemList.Items.Item(cbItemList.SelectedIndex) = sResult

        Call GenPWD()
    End Sub
    ' STATUS: DONE
    Private Sub rb120bits_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rb120bits.CheckedChanged
        If bSetting = True Then Exit Sub
        bSetting = True
        rb40bits.Checked = False
        rb60bits.Checked = False
        rb80bits.Checked = False
        rb120bits.Checked = True
        rb160bits.Checked = False
        bSetting = False

        If cbItemList.SelectedIndex = -1 Then Exit Sub
        Dim sResult As String = cbItemList.Items.Item(cbItemList.SelectedIndex).ToString
        sResult = sResult.Replace("|40|", "|120|")
        sResult = sResult.Replace("|60|", "|120|")
        sResult = sResult.Replace("|80|", "|120|")
        sResult = sResult.Replace("|160|", "|120|")
        cbItemList.Items.Item(cbItemList.SelectedIndex) = sResult

        Call GenPWD()
    End Sub
    ' STATUS: DONE
    Private Sub rb160bits_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rb160bits.CheckedChanged
        If bSetting = True Then Exit Sub
        bSetting = True
        rb40bits.Checked = False
        rb60bits.Checked = False
        rb80bits.Checked = False
        rb120bits.Checked = False
        rb160bits.Checked = True
        bSetting = False

        If cbItemList.SelectedIndex = -1 Then Exit Sub
        Dim sResult As String = cbItemList.Items.Item(cbItemList.SelectedIndex).ToString
        sResult = sResult.Replace("|40|", "|160|")
        sResult = sResult.Replace("|60|", "|160|")
        sResult = sResult.Replace("|80|", "|160|")
        sResult = sResult.Replace("|120|", "|160|")
        cbItemList.Items.Item(cbItemList.SelectedIndex) = sResult

        Call GenPWD()
    End Sub

    ' STATUS: DONE
    Private Sub cmdNewSeed_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdNewSeed.Click

        Dim rx As System.Text.RegularExpressions.Regex

        Randomize(Now.Millisecond) ' v2.1
        Dim i As Integer = Int(Rnd(8912741) * 99999999) + 1 ' Just has to be unique, its not a Secure PRNG.

        If cbItemList.SelectedIndex = -1 Then Exit Sub
        Dim sResult As String = cbItemList.Items.Item(cbItemList.SelectedIndex).ToString
        sResult = rx.Replace(sResult, "S\=[0-9]{1,8}\|", "S=" & i.ToString & "|")
        cbItemList.Items.Item(cbItemList.SelectedIndex) = sResult

        Call GenPWD()
        MsgBox("The entropy seed value has been changed. This change is implicitly NOT automatically saved, so you have to choose to do that yourself by clicking the SAVE button." & vbCrLf & vbCrLf & "If you did not want to save the seed, just click the [Load] button and the seed value will be restored.", MsgBoxStyle.Exclamation, "PLEASE NOTE!")

    End Sub

    ' STATUS: DONE
    Private Sub cbSpecialChar_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cbSpecialChar.CheckedChanged

        If bSetting = True Then Exit Sub
        If cbItemList.SelectedIndex = -1 Then Exit Sub


        Dim sResult As String = cbItemList.Items.Item(cbItemList.SelectedIndex).ToString

        If cbSpecialChar.Checked = True Then sResult = sResult & "SPECIALCHARS"
        If cbSpecialChar.Checked = False Then sResult = sResult.Replace("|SPECIALCHARS", "|")

        cbItemList.Items.Item(cbItemList.SelectedIndex) = sResult

    End Sub

    ' STATUS: DONE
    Private Sub cmdAdd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdAdd.Click

        Dim sResult As String = ""

        sResult = InputBox("Enter site, place, server, email adress that you want to generate a password for. Do not use the pipe ''|'' sign.", "For what are you using the password?", "www.site.com, server8, something@example.net")
        If sResult.Trim = "" Then Exit Sub
        If InStr(sResult.Trim, "|") > 0 Then Exit Sub

        Randomize(Now.Millisecond) ' v2.1
        Dim i As Integer = Int(Rnd(8912741) * 99999999) + 1 ' Just has to be unique, its not a Secure PRNG.
        sResult = sResult & "                    |S=" & i.ToString & "|160|SPECIALCHARS" ' Default to strong setting, let the user downgrade

        cbItemList.Items.Add(sResult)
        cbItemList.SelectedIndex = cbItemList.Items.Count - 1

    End Sub

    ' STATUS: DONE
    Private Sub cmdDelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdDelete.Click
        If cbItemList.SelectedIndex = -1 Then Exit Sub

        Dim i As Integer = 0
        i = MsgBox("Are you sure you want to remove the item?", MsgBoxStyle.YesNo + MsgBoxStyle.Exclamation, "Alert")
        If i <> 6 Then Exit Sub

        cbItemList.Items.RemoveAt(cbItemList.SelectedIndex)
        cbItemList.Text = ""
    End Sub

    ' STATUS: DONE
    Private Sub cbItemList_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cbItemList.SelectedIndexChanged
        txtPasswordPassphrase.Focus()

        bSetting = True

        rb40bits.Checked = False
        rb60bits.Checked = False
        rb80bits.Checked = False
        rb120bits.Checked = False
        rb160bits.Checked = False

        If InStr(cbItemList.Items.Item(cbItemList.SelectedIndex).ToString, "|40|") Then rb40bits.Checked = True
        If InStr(cbItemList.Items.Item(cbItemList.SelectedIndex).ToString, "|60|") Then rb60bits.Checked = True
        If InStr(cbItemList.Items.Item(cbItemList.SelectedIndex).ToString, "|80|") Then rb80bits.Checked = True
        If InStr(cbItemList.Items.Item(cbItemList.SelectedIndex).ToString, "|120|") Then rb120bits.Checked = True
        If InStr(cbItemList.Items.Item(cbItemList.SelectedIndex).ToString, "|160|") Then rb160bits.Checked = True

        cbSpecialChar.Checked = False
        If InStr(cbItemList.Items.Item(cbItemList.SelectedIndex).ToString, "|SPECIALCHARS") Then cbSpecialChar.Checked = True

        bSetting = False

        Call GenPWD()

    End Sub

    ' STATUS: DONE
    Private Sub cmdReload_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdReload.Click

        Me.cbItemList.Items.Clear()
        Me.cbItemList.Text = ""
        txtGeneratedPasword.Text = "" ' v2.1

        ' Reload entropyfile.
        If Dir(sFilename) <> "" Then
            Dim i As Integer = FreeFile()
            Dim sReadLine As String = ""
            FileOpen(i, sFilename, OpenMode.Input)
            While Not EOF(i)
                sReadLine = LineInput(i)
                If Microsoft.VisualBasic.Left(sReadLine, 3) = "LS=" Then ' Localseed param
                    sLocalSeed = sReadLine.Replace("LS=", "")
                    sReadLine = ""
                End If
                sReadLine = sReadLine.Replace(vbCr, "")
                sReadLine = sReadLine.Replace(vbLf, "")
                If sReadLine.Trim <> "" Then Me.cbItemList.Items.Add(sReadLine)
            End While
            FileClose(i)

        End If

    End Sub

    ' STATUS: DONE
    Private Sub cmdSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdSave.Click

        Dim sResult As String = ""

        For n = 0 To (cbItemList.Items.Count - 1)
            If cbItemList.Items.Item(n).ToString.Trim <> "" Then
                sResult = sResult & cbItemList.Items.Item(n).ToString & vbCrLf
            End If
        Next

        Dim i As Integer = FreeFile()
        FileOpen(i, sFilename, OpenMode.Output)
        Print(i, "LS=" & sLocalSeed & vbCrLf)
        Print(i, sResult)
        FileClose(i)

    End Sub

    ' STATUS: DONE
    Private Sub txtGeneratedPasword_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtGeneratedPasword.GotFocus
        txtGeneratedPasword.SelectAll()
    End Sub

    ' STATUS: In development. Problems with ^ sign
    Private Sub tmrHotkey_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tmrHotkey.Tick
        tmrHotkey.Enabled = False


        Dim sPW As String = txtGeneratedPasword.Text

        If sPW.Trim <> "" Then

            Dim z As Integer = 0

            For n = 0 To 255
                '    z = (GetAsyncKeyState(n) Mod 2)
                '    If z <> 0 Then txtGeneratedPasword.Text = n
            Next


            Dim sTMPChar As String = ""
            If (GetAsyncKeyState(145) Mod 2) > 0 Then ' scroll lock sends pw to field
                For n = 1 To Len(sPW)
                    sTMPChar = Microsoft.VisualBasic.Mid(sPW, n, 1)
                    Select Case sTMPChar
                        Case "!"
                            sTMPChar = "!"
                        Case "#"
                            sTMPChar = "#"
                        Case "$"
                            sTMPChar = "$"
                        Case "{"
                            sTMPChar = "{{}"
                        Case "}"
                            sTMPChar = "{}}"
                        Case "("
                            sTMPChar = "{(}"
                        Case ")"
                            sTMPChar = "{)}"
                        Case "@"
                            sTMPChar = "@"
                        Case "^"
                            sTMPChar = "{^}" '%(94)" ' funkar inte vad jag än gör. WTF?
                    End Select
                    ' Documentation for special char converseion @
                    ' https://msdn.microsoft.com/en-us/library/system.windows.forms.sendkeys%28v=vs.110%29.aspx
                    Try
                        System.Windows.Forms.SendKeys.Send(sTMPChar)
                        ' Överväg byta ut SendKeys() till Keybd_Event()
                        ' vilket inte  förstör ^ = kompatibilitet


                    Catch ex As Exception
                        MsgBox(ex.Message)
                    End Try

                Next
            End If
        End If


        tmrHotkey.Enabled = True
    End Sub
End Class
