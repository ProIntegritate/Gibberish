﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.cbItemList = New System.Windows.Forms.ComboBox()
        Me.txtPasswordPassphrase = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtPwHint = New System.Windows.Forms.TextBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.rb120bits = New System.Windows.Forms.RadioButton()
        Me.rb60bits = New System.Windows.Forms.RadioButton()
        Me.cbSpecialChar = New System.Windows.Forms.CheckBox()
        Me.cmdHelpPwdStrenght = New System.Windows.Forms.Button()
        Me.rb160bits = New System.Windows.Forms.RadioButton()
        Me.rb80bits = New System.Windows.Forms.RadioButton()
        Me.rb40bits = New System.Windows.Forms.RadioButton()
        Me.txtGeneratedPasword = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.cmdNewSeed = New System.Windows.Forms.Button()
        Me.cmdAdd = New System.Windows.Forms.Button()
        Me.cmdDelete = New System.Windows.Forms.Button()
        Me.cmdReload = New System.Windows.Forms.Button()
        Me.cmdSave = New System.Windows.Forms.Button()
        Me.tmrHotkey = New System.Windows.Forms.Timer(Me.components)
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'cbItemList
        '
        Me.cbItemList.BackColor = System.Drawing.SystemColors.Control
        Me.cbItemList.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbItemList.FormattingEnabled = True
        Me.cbItemList.Location = New System.Drawing.Point(11, 31)
        Me.cbItemList.MaxDropDownItems = 15
        Me.cbItemList.Name = "cbItemList"
        Me.cbItemList.Size = New System.Drawing.Size(559, 28)
        Me.cbItemList.TabIndex = 0
        Me.cbItemList.TabStop = False
        '
        'txtPasswordPassphrase
        '
        Me.txtPasswordPassphrase.Location = New System.Drawing.Point(13, 86)
        Me.txtPasswordPassphrase.Name = "txtPasswordPassphrase"
        Me.txtPasswordPassphrase.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.txtPasswordPassphrase.Size = New System.Drawing.Size(312, 20)
        Me.txtPasswordPassphrase.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(11, 15)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(398, 13)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "1. Select Site / Server / Email adress or whatever you have entered:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.White
        Me.Label2.Location = New System.Drawing.Point(13, 70)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(208, 13)
        Me.Label2.TabIndex = 6
        Me.Label2.Text = "2. Enter a Password or passphrase:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.White
        Me.Label3.Location = New System.Drawing.Point(347, 70)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(77, 13)
        Me.Label3.TabIndex = 7
        Me.Label3.Text = "Spelling hint"
        '
        'txtPwHint
        '
        Me.txtPwHint.BackColor = System.Drawing.SystemColors.Control
        Me.txtPwHint.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPwHint.Location = New System.Drawing.Point(350, 86)
        Me.txtPwHint.Name = "txtPwHint"
        Me.txtPwHint.ReadOnly = True
        Me.txtPwHint.Size = New System.Drawing.Size(74, 31)
        Me.txtPwHint.TabIndex = 8
        Me.txtPwHint.TabStop = False
        Me.txtPwHint.Text = "-"
        Me.txtPwHint.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.GroupBox1.Controls.Add(Me.rb120bits)
        Me.GroupBox1.Controls.Add(Me.rb60bits)
        Me.GroupBox1.Controls.Add(Me.cbSpecialChar)
        Me.GroupBox1.Controls.Add(Me.cmdHelpPwdStrenght)
        Me.GroupBox1.Controls.Add(Me.rb160bits)
        Me.GroupBox1.Controls.Add(Me.rb80bits)
        Me.GroupBox1.Controls.Add(Me.rb40bits)
        Me.GroupBox1.Location = New System.Drawing.Point(455, 67)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(175, 147)
        Me.GroupBox1.TabIndex = 33
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Password strenght"
        '
        'rb120bits
        '
        Me.rb120bits.AutoSize = True
        Me.rb120bits.Location = New System.Drawing.Point(16, 75)
        Me.rb120bits.Name = "rb120bits"
        Me.rb120bits.Size = New System.Drawing.Size(134, 17)
        Me.rb120bits.TabIndex = 35
        Me.rb120bits.Text = "24 character (120  bits)"
        Me.rb120bits.UseVisualStyleBackColor = True
        '
        'rb60bits
        '
        Me.rb60bits.AutoSize = True
        Me.rb60bits.Location = New System.Drawing.Point(16, 38)
        Me.rb60bits.Name = "rb60bits"
        Me.rb60bits.Size = New System.Drawing.Size(128, 17)
        Me.rb60bits.TabIndex = 33
        Me.rb60bits.Text = "12 character (60  bits)"
        Me.rb60bits.UseVisualStyleBackColor = True
        '
        'cbSpecialChar
        '
        Me.cbSpecialChar.AutoSize = True
        Me.cbSpecialChar.Checked = True
        Me.cbSpecialChar.CheckState = System.Windows.Forms.CheckState.Checked
        Me.cbSpecialChar.Location = New System.Drawing.Point(16, 116)
        Me.cbSpecialChar.Name = "cbSpecialChar"
        Me.cbSpecialChar.Size = New System.Drawing.Size(143, 17)
        Me.cbSpecialChar.TabIndex = 37
        Me.cbSpecialChar.TabStop = False
        Me.cbSpecialChar.Text = "Special characters (!$@]"
        Me.cbSpecialChar.UseVisualStyleBackColor = True
        '
        'cmdHelpPwdStrenght
        '
        Me.cmdHelpPwdStrenght.BackColor = System.Drawing.Color.LightGray
        Me.cmdHelpPwdStrenght.Location = New System.Drawing.Point(144, 13)
        Me.cmdHelpPwdStrenght.Name = "cmdHelpPwdStrenght"
        Me.cmdHelpPwdStrenght.Size = New System.Drawing.Size(25, 23)
        Me.cmdHelpPwdStrenght.TabIndex = 11
        Me.cmdHelpPwdStrenght.TabStop = False
        Me.cmdHelpPwdStrenght.Text = "?"
        Me.cmdHelpPwdStrenght.UseVisualStyleBackColor = False
        '
        'rb160bits
        '
        Me.rb160bits.AutoSize = True
        Me.rb160bits.Checked = True
        Me.rb160bits.Location = New System.Drawing.Point(16, 93)
        Me.rb160bits.Name = "rb160bits"
        Me.rb160bits.Size = New System.Drawing.Size(134, 17)
        Me.rb160bits.TabIndex = 36
        Me.rb160bits.TabStop = True
        Me.rb160bits.Text = "32 character (160  bits)"
        Me.rb160bits.UseVisualStyleBackColor = True
        '
        'rb80bits
        '
        Me.rb80bits.AutoSize = True
        Me.rb80bits.Location = New System.Drawing.Point(16, 57)
        Me.rb80bits.Name = "rb80bits"
        Me.rb80bits.Size = New System.Drawing.Size(128, 17)
        Me.rb80bits.TabIndex = 34
        Me.rb80bits.Text = "16 character (80  bits)"
        Me.rb80bits.UseVisualStyleBackColor = True
        '
        'rb40bits
        '
        Me.rb40bits.AutoSize = True
        Me.rb40bits.Location = New System.Drawing.Point(16, 19)
        Me.rb40bits.Name = "rb40bits"
        Me.rb40bits.Size = New System.Drawing.Size(122, 17)
        Me.rb40bits.TabIndex = 32
        Me.rb40bits.Text = "8 character (40  bits)"
        Me.rb40bits.UseVisualStyleBackColor = True
        '
        'txtGeneratedPasword
        '
        Me.txtGeneratedPasword.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtGeneratedPasword.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtGeneratedPasword.Location = New System.Drawing.Point(14, 132)
        Me.txtGeneratedPasword.Name = "txtGeneratedPasword"
        Me.txtGeneratedPasword.Size = New System.Drawing.Size(428, 31)
        Me.txtGeneratedPasword.TabIndex = 2
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.White
        Me.Label4.Location = New System.Drawing.Point(11, 116)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(197, 13)
        Me.Label4.TabIndex = 11
        Me.Label4.Text = "Here is your generated password:"
        '
        'cmdNewSeed
        '
        Me.cmdNewSeed.BackColor = System.Drawing.Color.LightGray
        Me.cmdNewSeed.Location = New System.Drawing.Point(455, 5)
        Me.cmdNewSeed.Name = "cmdNewSeed"
        Me.cmdNewSeed.Size = New System.Drawing.Size(75, 23)
        Me.cmdNewSeed.TabIndex = 3
        Me.cmdNewSeed.Text = "New Seed"
        Me.cmdNewSeed.UseVisualStyleBackColor = False
        '
        'cmdAdd
        '
        Me.cmdAdd.BackColor = System.Drawing.Color.LightGray
        Me.cmdAdd.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdAdd.Location = New System.Drawing.Point(576, 38)
        Me.cmdAdd.Name = "cmdAdd"
        Me.cmdAdd.Size = New System.Drawing.Size(29, 23)
        Me.cmdAdd.TabIndex = 6
        Me.cmdAdd.Text = "+"
        Me.cmdAdd.UseVisualStyleBackColor = False
        '
        'cmdDelete
        '
        Me.cmdDelete.BackColor = System.Drawing.Color.LightGray
        Me.cmdDelete.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdDelete.Location = New System.Drawing.Point(602, 38)
        Me.cmdDelete.Name = "cmdDelete"
        Me.cmdDelete.Size = New System.Drawing.Size(29, 23)
        Me.cmdDelete.TabIndex = 7
        Me.cmdDelete.Text = "-"
        Me.cmdDelete.UseVisualStyleBackColor = False
        '
        'cmdReload
        '
        Me.cmdReload.BackColor = System.Drawing.Color.LightGray
        Me.cmdReload.Location = New System.Drawing.Point(536, 5)
        Me.cmdReload.Name = "cmdReload"
        Me.cmdReload.Size = New System.Drawing.Size(44, 23)
        Me.cmdReload.TabIndex = 4
        Me.cmdReload.Text = "Load"
        Me.cmdReload.UseVisualStyleBackColor = False
        '
        'cmdSave
        '
        Me.cmdSave.BackColor = System.Drawing.Color.LightGray
        Me.cmdSave.Location = New System.Drawing.Point(586, 5)
        Me.cmdSave.Name = "cmdSave"
        Me.cmdSave.Size = New System.Drawing.Size(44, 23)
        Me.cmdSave.TabIndex = 5
        Me.cmdSave.Text = "Save"
        Me.cmdSave.UseVisualStyleBackColor = False
        '
        'tmrHotkey
        '
        Me.tmrHotkey.Enabled = True
        Me.tmrHotkey.Interval = 250
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Green
        Me.ClientSize = New System.Drawing.Size(643, 223)
        Me.Controls.Add(Me.cmdSave)
        Me.Controls.Add(Me.cmdReload)
        Me.Controls.Add(Me.cmdDelete)
        Me.Controls.Add(Me.cmdAdd)
        Me.Controls.Add(Me.cmdNewSeed)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.txtGeneratedPasword)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.txtPwHint)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txtPasswordPassphrase)
        Me.Controls.Add(Me.cbItemList)
        Me.ForeColor = System.Drawing.Color.Black
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Gibberish 2.2 (Generative password manager by Glenn Larsson)"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents cbItemList As System.Windows.Forms.ComboBox
    Friend WithEvents txtPasswordPassphrase As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txtPwHint As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents cmdHelpPwdStrenght As System.Windows.Forms.Button
    Friend WithEvents rb160bits As System.Windows.Forms.RadioButton
    Friend WithEvents rb80bits As System.Windows.Forms.RadioButton
    Friend WithEvents rb40bits As System.Windows.Forms.RadioButton
    Friend WithEvents cbSpecialChar As System.Windows.Forms.CheckBox
    Friend WithEvents txtGeneratedPasword As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents cmdNewSeed As System.Windows.Forms.Button
    Friend WithEvents cmdAdd As System.Windows.Forms.Button
    Friend WithEvents cmdDelete As System.Windows.Forms.Button
    Friend WithEvents cmdReload As System.Windows.Forms.Button
    Friend WithEvents cmdSave As System.Windows.Forms.Button
    Friend WithEvents rb60bits As System.Windows.Forms.RadioButton
    Friend WithEvents rb120bits As System.Windows.Forms.RadioButton
    Friend WithEvents tmrHotkey As System.Windows.Forms.Timer

End Class
